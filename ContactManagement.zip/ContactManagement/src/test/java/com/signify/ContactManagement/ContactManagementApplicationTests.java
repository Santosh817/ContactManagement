package com.signify.ContactManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
